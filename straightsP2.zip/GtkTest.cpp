#include <gtkmm.h>

int main(int argc, char* arv[]){
	Gtk::Main kit (argc, argv);
	Gtk::window window;
	Gtk::Main::run( window );
	return 0;
}