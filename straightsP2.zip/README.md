cs247_straights
===============
