#ifndef PLAYERVIEW_H
#define PLAYERVIEW_H

class PlayerView : public Subject{
	public: 
	protected:
		notify();
};

#endif